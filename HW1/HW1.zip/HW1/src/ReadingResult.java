class ReadingResult implements IChallenge {


    int bookspd;
    BooksReadFiction brfic;
    BooksReadNonFiction brnonfic;

    ReadingResult (Integer bookspd, BooksReadFiction brfic, BooksReadNonFiction brnonfic) {
        this.bookspd = bookspd;
        this.brfic = brfic;
        this.brnonfic = brnonfic;
    }

    public double averagePerDay() {
        return (brfic.BooksRead + brnonfic.BooksReadnf)/31;
    }

    public double differenceFromGoal() {
        return bookspd - averagePerDay();
    }
}
