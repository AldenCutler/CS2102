import org.junit.Test;
import static org.junit.Assert.*;

public class Examples {
    BooksReadFiction brfAlden = new BooksReadFiction(5);
    BooksReadNonFiction brnfAlden = new BooksReadNonFiction(4);
    ReadingResult rrAlden = new ReadingResult(1,brfAlden,brnfAlden);
    WritingResult wrAlden = new WritingResult(700, 15);
    ChallengeResult crAlden = new ChallengeResult(rrAlden, wrAlden);
    Literarian Alden = new Literarian(crAlden);

    BooksReadNonFiction brnfMax = new BooksReadNonFiction(7);
    BooksReadFiction brfMax = new BooksReadFiction(5);
    ReadingResult rrMax  = new ReadingResult(3, brfMax, brnfMax);
    WritingResult wrMax = new WritingResult(400, 10);
    ChallengeResult crMax = new ChallengeResult(rrMax, wrMax);
    Literarian Max = new Literarian(crMax);


    @Test
    public void rrbspd() {
        assertEquals(1, Alden.ChallengeResult.ReadingResult.bookspd);
        assertEquals(3, Max.ChallengeResult.ReadingResult.bookspd);
    }
    @Test
    public void bb() {
        assertTrue(Alden.betterBookworm(Max));
        assertFalse(Max.betterBookworm(Alden));
    }
    @Test
    public void ww() {
        assertFalse(Alden.wittierWordsmith(Max));
        assertTrue(Max.wittierWordsmith(Alden));
    }
}
