public class booksread {
    double booksreadfiction;
    double booksreadnonfiction;
    

}
