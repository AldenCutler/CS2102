public interface IChallenge {
    public double averagePerDay();
    public double differenceFromGoal();
}
