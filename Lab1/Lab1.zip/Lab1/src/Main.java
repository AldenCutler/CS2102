class Main {

    public static void main(String[] args) {
        System.out.println("This doesn't do anything on its own. Run your tests.");
    }
}