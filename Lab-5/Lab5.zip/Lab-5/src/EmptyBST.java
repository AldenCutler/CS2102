public class EmptyBST implements IBST {
    EmptyBST() {}

    // no elements in an empty BST so returns 0
    public int size () {
        return 0;
    }

    // adding an element to an empty BST results in a new BST with the given element as the only node
    public IBST addElt (String elt) {
        return new BST(elt, new EmptyBST(), new EmptyBST());
    }

    // no elements in empty BST so returns false
    public boolean hasElt (String elt) {
        return false;
    }
}

