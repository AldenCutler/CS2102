public class BST implements IBST {
    String name;
    ISet right;
    ISet left;

    BST(String name, ISet right, ISet left) { // Constructor
        this.name = name;
        this.right = right;
        this.left = left;
    }

    // returns the total number of nodes in the tree
    public int size() {
        return 1 + this.right.size() + this.left.size();
    }

    // returns a BST that is exactly the same as the original, expect the String elt has been added to its correct
    // place in the tree
    public IBST addElt (String elt) {
        if (elt.equals(this.name)) {
            return this;
        } else if (elt.compareTo(this.name) < 0) {
            return new BST(this.name, this.left.addElt(elt), this.right);
        } else return new BST (this.name, this.left, this.right.addElt(elt));
    }

    // returns a boolean that represents whether the given element is present anywhere in the tree
    public boolean hasElt (String elt) {
        return elt.equals(this.name) || this.right.hasElt(elt) || this.left.hasElt(elt);
    }
}
