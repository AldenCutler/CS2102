public class Main {
    public static void main(String[] args) {
        VoteBooth votebooth = new VoteBooth();
//        votebooth.voteD.votes.add("Husky");
//        System.out.println(votebooth.voteD.countVotes("Husky"));
        votebooth.screen();
    }
}