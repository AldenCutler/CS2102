public class VotingProgram {
    public static void main (String [] args) {
        PollingDevice device = new PollingDevice();

        device.screen();
    }
}