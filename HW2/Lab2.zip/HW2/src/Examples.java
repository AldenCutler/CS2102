import static org.junit.Assert.*;
import org.junit.Test;

public class Examples {
    Fish robert = new Fish(5, 3.75);
    Shark larry = new Shark(10, 2);
    Boa steve = new Boa("Steve",26, "people");
    Dillo dan = new Dillo(3, false);

    @Test
    public void isDanger(){
        assertTrue(larry.isDangerToPeople());
        assertTrue(steve.isDangerToPeople());
        assertFalse(robert.isDangerToPeople());
        assertFalse(dan.isDangerToPeople());
    }
    @Test
    public void normalSize(){
        assertTrue(robert.isNormalSize());
        assertTrue(larry.isNormalSize());
        assertFalse(steve.isNormalSize());
    }
}
