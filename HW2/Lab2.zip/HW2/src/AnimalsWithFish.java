public class AnimalsWithFish {

}