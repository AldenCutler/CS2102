interface IAnimal {
    boolean isNormalSize () ;
    boolean isDangerToPeople();
}