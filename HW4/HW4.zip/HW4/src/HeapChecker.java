public class HeapChecker {
    public boolean addEltValidator(IHeap hOrig, int elt , IBinTree hAdded) {
        if(hOrig.isHeap() && hAdded.isHeap()) {
            for(int i : hAdded.listOfElt()) {
                if(i == elt && hOrig.size() + 1 == hAdded.size()) {
                } else if(hOrig.countNumElt(i) == hAdded.countNumElt(i)) {
                } else return false;
            } return true;
        } return false;
    }

    public boolean remMinEltValidator(IHeap hOrig, IBinTree hRemoved) {
        if(hOrig.isHeap() && hRemoved.isHeap()) {
            for(int i : hOrig.listOfElt()) {
                if(i == hOrig.listOfElt().iterator().next() && hOrig.size() - 1 == hRemoved.size()) {
                } else if(hOrig.countNumElt(i) == hRemoved.countNumElt(i)) {
                } else return false;
            } return true;
        } return false;
    }
}