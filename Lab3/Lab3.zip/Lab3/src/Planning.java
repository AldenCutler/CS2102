import java.util.LinkedList;

public class Planning {
        LinkedList<Double> inchesRain;
        double acc = 0;
        double numpos = 0;

        public Planning(LinkedList<Double> inchesRain, double acc, double numpos) {
            this.inchesRain = inchesRain;
            this.acc = acc;
            this.numpos = numpos;
        }

        public double rainfall(LinkedList<Double> rain) {
            for (int i = 0; i < rain.size(); i++) {
                if(rain.get(0) == -999) {
                    break;
                } else if (rain.get(0) >= 0) {
                    acc += rain.get(0);
                    numpos ++;
                }
            }
            return acc/numpos;
        }
}
