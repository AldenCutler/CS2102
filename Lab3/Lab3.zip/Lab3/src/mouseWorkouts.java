public class mouseWorkouts {
    double workoutsPerDay;
    double workoutLength;
}
