public class Mouse {
    mouseFood food;
    mouseWorkouts workouts;
    mouseWeight weight;
}
