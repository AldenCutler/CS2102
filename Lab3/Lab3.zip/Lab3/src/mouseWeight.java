public class mouseWeight {
    double weight;
    double day;
}
