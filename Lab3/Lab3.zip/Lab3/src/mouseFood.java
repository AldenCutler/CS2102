public class mouseFood {
    String foodType;
    double gramsFoodPerMeal;
}
